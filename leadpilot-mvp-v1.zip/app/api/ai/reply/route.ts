import { NextRequest } from "next/server";
import { generateReply } from "@/lib/ai";

export async function POST(req: NextRequest) {
  const body = await req.json();

  if (!body.customerMessage) {
    return Response.json({ error: "customerMessage required" }, { status: 400 });
  }

  const reply = await generateReply({
    customerMessage: body.customerMessage,
    businessInfo: body.businessInfo || "No business information supplied.",
    conversation: body.conversation || "",
  });

  return Response.json({ reply });
}
